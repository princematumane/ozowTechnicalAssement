using conwaygameoflife;
using conwaygameoflife.Enum;
using conwaygameoflife.Interface;
using Xunit;

namespace conwaygameoflifeTests
{
    public class GameTest
    {
        [Fact]
        public void Game_CorrectRowsAndCols()
        {
            // Arrange
            const int rows = 10;
            const int cols = 10;

            //act
            var gm = CreateGameObject().MakeCellGrid(rows, cols);

            //Assert
            Assert.Equal(rows * cols, gm.Length);
        }

        [Fact]
        public void NextGeneration_ReturnsNewGrid()
        {
            // Arrange
            const int rows = 10;
            const int cols = 10;
            var gm = CreateGameObject();

            // Act
            var currentGen = gm.MakeCellGrid(rows, cols);
            var newGenGrid = gm.NextGeneration(currentGen, rows, cols);

            // Assert
            Assert.NotSame(currentGen, newGenGrid);
        }

        [Fact]
        public void Game_killsCellsWithFewerThanTwoLives_returnsDead()
        {
            // Arrange
            const CellStatus expected = CellStatus.Dead;
            const CellStatus currentCell = CellStatus.Alive;
            var aliveNeighbours = 10;

            var gm = CreateGameObject();
            // Act
            var cell = gm.RulesOfLife(currentCell, aliveNeighbours);

            // Assert
            Assert.Equal(cell, expected);
        }

        [Fact]
        public void Game_SaveAnyCellWithTwoOrThreeLiveNeighbours()
        {
            // Arrange
            const CellStatus expected = CellStatus.Alive;
            const CellStatus currentCell = CellStatus.Alive;
            var aliveNeighbours = 2;
            var aliveNeighbours2 = 3;


            var gm = CreateGameObject();
            // Act
            var cell = gm.RulesOfLife(currentCell, aliveNeighbours);
            var cell1 = gm.RulesOfLife(currentCell, aliveNeighbours2);

            // Assert
            Assert.Equal(cell, expected);
            Assert.Equal(cell1, expected);
        }
        [Fact]
        public void Game_KillsCellWithMoreThanThreeLiveNeighbours()
        {
            // Arrange
            const CellStatus expected = CellStatus.Dead;
            const CellStatus currentCell = CellStatus.Alive;
            var aliveNeighbours = 5;

            var gm = CreateGameObject();
            // Act
            var cell = gm.RulesOfLife(currentCell, aliveNeighbours);

            // Assert
            Assert.Equal(cell, expected);
        }

        [Fact]
        public void Game_KeepAliveDeadCellWithThreeLiveNeighbours()
        {
            // Arrange
            const CellStatus expected = CellStatus.Alive;
            const CellStatus currentCell = CellStatus.Dead;
            var aliveNeighbours = 3;

            // Act
            var gm = CreateGameObject();
            var cell = gm.RulesOfLife(currentCell, aliveNeighbours);

            // Assert
            Assert.Equal(cell, expected);
        }
        private IGame CreateGameObject()
        {
            return new Game(); ;
        }
    }
}
