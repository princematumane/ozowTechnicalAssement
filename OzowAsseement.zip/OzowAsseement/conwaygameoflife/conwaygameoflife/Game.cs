﻿using conwaygameoflife.Enum;
using conwaygameoflife.Interface;
using System;
using System.Threading;

namespace conwaygameoflife
{
    public class Game : IGame
    {

        private readonly Random _random;

        public Game()
        {
            _random = new Random();
        }
        /// <summary>
        /// Start game
        /// </summary>
        public void Start()
        {
            try
            {
                //get user input 

                Console.WriteLine("Please enter the number of rows   = ");
                var rows = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Please enter the number of columns  = ");
                var cols = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Please enter the number of generations  = ");
                var numberOfGenerations = Convert.ToInt32(Console.ReadLine());

                var grid = MakeCellGrid(rows, cols);

                Console.Clear();
                for (var i = 0; i < numberOfGenerations; i++)
                {
                    Display(grid, rows, cols);
                    grid = NextGeneration(grid, rows, cols);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.ReadKey();
            }

        }
        private static void Display(CellStatus[,] future, int rows, int cols)
        {
            var gameCell = string.Empty;
            for (var x = 0; x < rows; x++)
            {
                for (var y = 0; y < cols; y++)
                {
                    var cell = future[x, y];
                    gameCell += cell == CellStatus.Alive ? "*" : "-";
                }

                gameCell += "\n";
            }

            Console.BackgroundColor = ConsoleColor.Black;
            Console.CursorVisible = false;
            Console.SetCursorPosition(0, 0);
            Console.WriteLine($"Alive = * ");
            Console.WriteLine(gameCell);
            Thread.Sleep(500);
        }
        /// <summary>
        /// Receive row and column to return a new random grid
        /// </summary>
        /// <param name="rows"></param>
        /// <param name="cols"></param>
        /// <returns></returns>
        public CellStatus[,] MakeCellGrid(int rows, int cols)
        {
            var grid = new CellStatus[rows, cols];

            for (var x = 0; x < rows; x++)
            {
                for (var y = 0; y < cols; y++)
                {
                    //create random status for each cell
                    grid[x, y] = (CellStatus)_random.Next(0, 2);
                }
            }
            return grid;
        }/// <summary>
         /// Check/Find neighbour cell is alive basse of the current grid
         /// </summary>
         /// <param name="currentGrid"></param>
         /// <param name="x"></param>
         /// <param name="y"></param>
         /// <returns></returns>
        public (CellStatus, int) AliveNeighbour(CellStatus[,] currentGrid, int x, int y)
        {
            var neighbourAlive = 0;
            for (var i = -1; i <= 1; i++)
            {
                for (var j = -1; j <= 1; j++)
                {
                    neighbourAlive += currentGrid[x + i, y + j] == CellStatus.Alive ? 1 : 0;
                }
            }
            var currentCell = currentGrid[x, y];
            neighbourAlive -= currentCell == CellStatus.Alive ? 1 : 0;
            return (currentCell, neighbourAlive);
        }

        public CellStatus RulesOfLife(CellStatus currentCell, int neighbourAlive)
        {
            //    Any live cell with fewer than two live neighbours dies, as if by underpopulation.
            //    Any live cell with two or three live neighbours lives on to the next generation.
            //    Any live cell with more than three live neighbours dies, as if by overpopulation.
            //    Any dead cell with exactly three live neighbours becomes a live cell, as if by reproduction

            if (currentCell.HasFlag(CellStatus.Alive) && neighbourAlive < 2)
            {
                return CellStatus.Dead;
            }
            else if (currentCell.HasFlag(CellStatus.Alive) && neighbourAlive > 3)
            {
                //kill the cell due to over population
                return CellStatus.Dead;
            }
            else if (currentCell.HasFlag(CellStatus.Dead) && neighbourAlive == 3)
            {
                // create a new cell
                return CellStatus.Alive;
            }
            else
            {
                return currentCell;
            }
        }

        public CellStatus[,] NextGeneration(CellStatus[,] currentGrid, int rows, int cols)
        {
            var nextGeneration = new CellStatus[rows, cols];

            for (var x = 1; x < rows - 1; x++)
                for (var y = 1; y < cols - 1; y++)
                {
                    var (currentCell, neighbourAlive) = AliveNeighbour(currentGrid, x, y);
                    // staring the Rules of Life 
                    nextGeneration[x, y] = RulesOfLife(currentCell, neighbourAlive);

                }
            return nextGeneration;
        }
    }
}
