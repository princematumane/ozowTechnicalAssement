﻿using conwaygameoflife.Interface;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace conwaygameoflife
{
    class Program
    {
        private static ServiceProvider _serviceProvider;

        public static void Main()
        {
            RegisterServices();
            var scope = _serviceProvider.CreateScope();
            scope.ServiceProvider.GetRequiredService<IGame>().Start();
            Console.ReadKey();
        }

        private static void RegisterServices()
        {
            var services = new ServiceCollection();
            services.AddScoped<IGame, Game>();
            _serviceProvider = services.BuildServiceProvider(true);
        }

    }
}
