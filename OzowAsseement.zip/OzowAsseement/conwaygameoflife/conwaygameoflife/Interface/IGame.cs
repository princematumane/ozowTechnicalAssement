﻿using conwaygameoflife.Enum;

namespace conwaygameoflife.Interface
{
    public interface IGame
    {
        CellStatus[,] MakeCellGrid(int rows, int cols);
        CellStatus[,] NextGeneration(CellStatus[,] currentGrid, int rows, int cols);

        void Start();

        CellStatus RulesOfLife(CellStatus currentCell, int neighbourAlive);
        (CellStatus, int) AliveNeighbour(CellStatus[,] currentGrid, int row, int col);
    }
}
