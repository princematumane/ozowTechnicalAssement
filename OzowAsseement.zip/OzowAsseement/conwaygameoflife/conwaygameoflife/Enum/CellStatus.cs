﻿namespace conwaygameoflife.Enum
{
    public enum CellStatus
    {
        Dead,
        Alive,
    }
}