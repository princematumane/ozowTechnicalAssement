using ozowAssesment;
using Xunit;

namespace OzowAssementTest
{
    public class StringHelperTest
    {

        [Fact]
        public void ReceivesString_RemovesPunctuations()
        {
            //Arrange
            const string userInputSample = "Contrary! ,to popular belief the pink unicorn flies east.";
            const string expectedResults = "Contrary to popular belief the pink unicorn flies east";

            //Act
            var actual = userInputSample.RemovePunctuation();

            //Assert
            Assert.Equal(expectedResults, actual);
        }
        [Fact]
        public void ReceivesString_RemovesWhiteSpaces()
        {
            //Arrange
            const string userInputSample = "Contrary to popular belief the pink unicorn flies east";
            const string expectedResults = "Contrarytopopularbeliefthepinkunicornflieseast";

            //Act
            var actual = userInputSample.RemoveWhiteSpace();

            //Assert
            Assert.Equal(expectedResults, actual);
        }

        [Fact]
        public void ReceivesString_ProcessStringRequirements()
        {
            //Arrange
            const string userInputSample = "Contrary to popular belief, the pink unicorn flies east.";
            const string expectedResults = "contrarytopopularbeliefthepinkunicornflieseast";

            //Act
            var actual = userInputSample.ProcessStringRequirements();

            //Assert
            Assert.Equal(expectedResults, actual);
        }

        [Fact]
        public void ReceivesString_SortStringLetterAlphabetically()
        {
            //Arrange
            const string userInputSample = "contrarytopopularbeliefthepinkunicornflieseast";
            const string expectedResults = "aaabcceeeeeffhiiiiklllnnnnooooppprrrrssttttuuy";

            //Act
            var actual = userInputSample.SortStringLetterAlphabetically();

            //Assert
            Assert.Equal(expectedResults, actual);
        }

        [Fact]
        public void ReceivesString_SortArbitraryText()
        {
            //Arrange
            const string userInputSample = "Contrary to popular belief, the pink unicorn flies east.";
            const string expectedResults = "aaabcceeeeeffhiiiiklllnnnnooooppprrrrssttttuuy";

            //Act
            var actual = userInputSample.SortArbitraryText();

            //Assert
            Assert.Equal(expectedResults, actual);
        }
    }
}
