﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace ozowAssesment
{
    public static class StringHelper
    {
        /// <summary>
        /// Remove white spaces from the given string
        /// </summary>
        /// <param name="userInput"></param>
        /// <returns></returns>
        public static string RemoveWhiteSpace(this string userInput)
        {
            if (string.IsNullOrEmpty(userInput))
            {
                throw new ArgumentException($"{nameof(userInput)} cannot be null or empty");
            }
            var words = userInput.Split(" ");
            var stringWithoutSpaces = string.Empty;
            foreach (var word in words)
            {
                stringWithoutSpaces += word;
            }

            return stringWithoutSpaces;
        }
        /// <summary>
        /// Removes any kind on punctuation marks on the given string
        /// </summary>
        /// <param name="userInput"></param>
        /// <returns></returns>
        public static string RemovePunctuation(this string userInput)
        {
            if (string.IsNullOrEmpty(userInput))
            {
                throw new ArgumentException($"{nameof(userInput)} cannot be null or empty");
            }
            var stringWithoutPunctuation = new string(userInput.Where(c => !char.IsPunctuation(c)).ToArray());
            return stringWithoutPunctuation;
        }
        /// <summary>
        /// Expect a string,then removes white space ,punctuation and convert all letter to lower casing
        /// </summary>
        /// <param name="userInput"></param>
        /// <returns></returns>
        public static string ProcessStringRequirements(this string userInput)
        {
            if (string.IsNullOrEmpty(userInput))
            {
                throw new ArgumentException($"{nameof(userInput)} cannot be null or empty");
            }
            return userInput.RemovePunctuation().RemoveWhiteSpace().ToLower();
        }

        public static string SortArbitraryText(this string userInput)
        {
            if (string.IsNullOrEmpty(userInput))
            {
                throw new ArgumentException($"{nameof(userInput)} cannot be null or empty");
            }
            return userInput.ProcessStringRequirements().SortStringLetterAlphabetically();
        }

        /// <summary>
        /// Sort all letter from a given string in alphabetical order
        /// </summary>
        /// <param name="userInput"></param>
        /// <returns></returns>
        public static string SortStringLetterAlphabetically(this string userInput)
        {
            if (string.IsNullOrEmpty(userInput))
            {
                throw new ArgumentException($"{nameof(userInput)} cannot be null or empty");
            }

            var ascii = Encoding.ASCII.GetBytes(userInput);

            var sorted = SortByteArray(ascii);
            var results = string.Empty;

            foreach (var c in sorted)
            {
                results += char.ConvertFromUtf32(c);
            }
            return results;
        }

        /// <summary>
        /// Sort the list of type byte that is  passed to the function in descending order 
        /// </summary>
        /// <param name="byteData"></param>
        /// <returns></returns>
        private static IEnumerable<byte> SortByteArray(IList<byte> byteData)
        {
            for (var i = 0; i < byteData.Count - 1; i++)
            {
                for (var j = i + 1; j < byteData.Count; j++)
                {
                    if (byteData[i] <= byteData[j]) continue;
                    var temp = byteData[i];
                    byteData[i] = byteData[j];
                    byteData[j] = temp;
                }
            }
            return byteData;
        }
    }
}
