﻿using Microsoft.Extensions.DependencyInjection;
using ozowAssesment;
using ozowAssesment.Interfaces;

namespace OzowAssesment
{
    class Program
    {
        private static ServiceProvider _serviceProvider;

        private static void Main(string[] args)
        {
            RegisterServices();
            var scope = _serviceProvider.CreateScope();
            scope.ServiceProvider.GetRequiredService<IStart>().Run();
        }

        private static void RegisterServices()
        {
            var services = new ServiceCollection();
            services.AddSingleton<IStart, Start>();
            _serviceProvider = services.BuildServiceProvider(true);
        }

    }
}
