﻿namespace ozowAssesment.Interfaces
{
    public interface IStart
    {
        void Run();
    }
}
