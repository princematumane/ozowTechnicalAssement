﻿using ozowAssesment.Interfaces;
using System;

namespace ozowAssesment
{

    public class Start : IStart
    {
        public void Run()
        {
            Console.WriteLine("Please write your sentence here");
            var userInput = Console.ReadLine();
            try
            {
                Console.WriteLine($"{userInput.SortArbitraryText()}");
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error occurred => {e.Message}");
            }
        }
    }
}
